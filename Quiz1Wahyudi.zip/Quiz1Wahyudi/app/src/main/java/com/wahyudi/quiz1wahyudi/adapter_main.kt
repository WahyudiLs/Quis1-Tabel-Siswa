package com.wahyudi.quiz1wahyudi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class adapter_main : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.adapter_main)
    }
}